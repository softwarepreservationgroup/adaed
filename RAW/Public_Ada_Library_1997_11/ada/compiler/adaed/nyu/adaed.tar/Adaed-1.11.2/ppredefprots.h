int predef_code(char *);
