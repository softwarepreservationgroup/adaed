/*
 * Copyright (C) 1985-1992  New York University
 * 
 * This file is part of the Ada/Ed-C system.  See the Ada/Ed README file for
 * warranty (none) and distribution info and also the GNU General Public
 * License for more details.

*/

char   *err_msg_syms (int);
int in_beacon(int);
int in_PREFERRED_FOR_SYMS (int, int);
int is_opener(int);
int	open_index (int);
char * token_val_des(char *);
char   *CLOSER_MESSAGE_SYMS (int);
