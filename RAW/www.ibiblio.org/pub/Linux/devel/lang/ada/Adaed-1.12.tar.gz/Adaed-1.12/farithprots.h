/*
 * Copyright (C) 1985-1992  New York University
 * 
 * This file is part of the Ada/Ed-C system.  See the Ada/Ed README file for
 * warranty (none) and distribution info and also the GNU General Public
 * License for more details.

 */

void int_tom(int *, long);
void int_mp2(int *, int);
void int_mul(int *, int *, int *);
long int_tol(int *);
void int_div(int *, int *, int *);
void pow_of5(int *, int);
