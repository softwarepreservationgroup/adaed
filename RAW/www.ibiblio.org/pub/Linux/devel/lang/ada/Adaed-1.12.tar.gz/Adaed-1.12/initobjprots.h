/*
 * Copyright (C) 1985-1992  New York University
 * 
 * This file is part of the Ada/Ed-C system.  See the Ada/Ed README file for
 * warranty (none) and distribution info and also the GNU General Public
 * License for more details.

 */

Node build_proc_init_ara(Symbol);
Node build_proc_init_rec(Symbol);
int is_discr_ref(Node);
Node remove_discr_ref(Node, Node);
Node build_init_call(Node, Symbol, Symbol, Node);
